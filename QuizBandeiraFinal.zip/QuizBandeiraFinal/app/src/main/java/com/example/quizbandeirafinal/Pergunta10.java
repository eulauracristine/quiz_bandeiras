package com.example.quizbandeirafinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pergunta10 extends AppCompatActivity {

    private ImageView imgirlanda;
    private RadioGroup rgAlternativas10;
    private RadioButton rb1J, rb2J, rb3J, rb4J;
    private Button btnResponderJ;

    private int pontuacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pergunta10);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imgirlanda = findViewById(R.id.imgirlanda);
        rgAlternativas10 = findViewById(R.id.rgAlternativas10);
        rb1J = findViewById(R.id.rb1J);
        rb2J = findViewById(R.id.rb2J);
        rb3J = findViewById(R.id.rb3J);
        rb4J = findViewById(R.id.rb4J);
        btnResponderJ = findViewById(R.id.btnResponderJ);

        pontuacao = getIntent().getIntExtra("pontuacao", 0);

        btnResponderJ.setOnClickListener(view -> {
            int idSelecionado = rgAlternativas10.getCheckedRadioButtonId();

            if (idSelecionado == R.id.rb1J) {
                pontuacao++;
            }

            Intent i = new Intent(this, Ranking.class);
            i.putExtra("pontuacao", pontuacao);
            startActivity(i);
            finish();

        });
    }
}