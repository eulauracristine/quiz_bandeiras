package com.example.quizbandeirafinal;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class TelaPrincipal extends AppCompatActivity {
    private Button btnComecar, btnSair;
    private EditText etNome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_principal);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnComecar = findViewById(R.id.btnComecar);
        etNome = findViewById(R.id.etNome);
        btnSair = findViewById(R.id.btnSair);


        btnComecar.setEnabled(true);

        etNome.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().length() > 0) {
                    btnComecar.setAlpha(1.0f);
                } else {
                    btnComecar.setAlpha(0.5f);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        btnComecar.setAlpha(0.5f);

        btnComecar.setOnClickListener(v -> {

            if (etNome.getText().toString().trim().isEmpty()) {
                Toast.makeText(
                        TelaPrincipal.this,
                        "É obrigatório preencher seu nome para iniciar mano",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            Quiz.nome = etNome.getText().toString();

            startActivity(new Intent(this, Pergunta.class));
            finish();
        });

        btnSair.setOnClickListener(v -> {
            finishAffinity();
        });
    }
}