package com.example.quizbandeirafinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pergunta extends AppCompatActivity {
    private ImageView ivCosta;
    private RadioGroup rgAlternativas1;
    private RadioButton rb1A, rb2A, rb3A, rb4A;
    private Button btnResponderA;

    private int pontuacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pergunta); // ✅ só uma vez

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ivCosta = findViewById(R.id.ivCosta);
        rgAlternativas1 = findViewById(R.id.rgAlternativas1);
        rb1A = findViewById(R.id.rb1A);
        rb2A = findViewById(R.id.rb2A);
        rb3A = findViewById(R.id.rb3A);
        rb4A = findViewById(R.id.rb4A);
        btnResponderA = findViewById(R.id.btnResponderA);

        pontuacao = getIntent().getIntExtra("pontuacao", 0);

        btnResponderA.setOnClickListener(view -> {
            int idSelecionado = rgAlternativas1.getCheckedRadioButtonId();

            if (idSelecionado == R.id.rb2A) {
                pontuacao++;
            }

            Intent i = new Intent(this, Pergunta2.class);
            i.putExtra("pontuacao", pontuacao);
            startActivity(i);
            finish();
        });
    }
}