package com.example.quizbandeirafinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pergunta7 extends AppCompatActivity {

    private ImageView imgquir;
    private RadioGroup rgAlternativas7;
    private RadioButton rb1G, rb2G, rb3G, rb4G;
    private Button btnResponderG;

    private int pontuacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pergunta7);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imgquir = findViewById(R.id.imgquir);
        rgAlternativas7 = findViewById(R.id.rgAlternativas7);
        rb1G = findViewById(R.id.rb1G);
        rb2G = findViewById(R.id.rb2G);
        rb3G = findViewById(R.id.rb3G);
        rb4G = findViewById(R.id.rb4G);
        btnResponderG = findViewById(R.id.btnResponderG);

        pontuacao = getIntent().getIntExtra("pontuacao", 0);

        btnResponderG.setOnClickListener(view -> {
            int idSelecionado = rgAlternativas7.getCheckedRadioButtonId();

            if (idSelecionado == R.id.rb4G) {
                pontuacao++;
            }

            Intent i = new Intent(this, Pergunta8.class);
            i.putExtra("pontuacao", pontuacao);
            startActivity(i);
            finish();

        });
    }
}