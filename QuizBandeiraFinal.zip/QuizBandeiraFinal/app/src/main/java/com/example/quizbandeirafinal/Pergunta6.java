package com.example.quizbandeirafinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pergunta6 extends AppCompatActivity {

    private ImageView imgbrasil;
    private RadioGroup rgAlternativas6;
    private RadioButton rb1F, rb2F, rb3F, rb4F;
    private Button btnResponderF;

    private int pontuacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pergunta6);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imgbrasil = findViewById(R.id.imgbrasil);
        rgAlternativas6 = findViewById(R.id.rgAlternativas6);
        rb1F = findViewById(R.id.rb1F);
        rb2F = findViewById(R.id.rb2F);
        rb3F = findViewById(R.id.rb3F);
        rb4F = findViewById(R.id.rb4F);
        btnResponderF = findViewById(R.id.btnResponderF);

        pontuacao = getIntent().getIntExtra("pontuacao", 0);

        btnResponderF.setOnClickListener(view -> {
            int idSelecionado = rgAlternativas6.getCheckedRadioButtonId();

            if (idSelecionado == R.id.rb2F) {
                pontuacao++;
            }

            Intent i = new Intent(this, Pergunta7.class);
            i.putExtra("pontuacao", pontuacao);
            startActivity(i);
            finish();

        });
    }
}