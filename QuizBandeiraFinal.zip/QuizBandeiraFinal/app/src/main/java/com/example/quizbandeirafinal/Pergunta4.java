package com.example.quizbandeirafinal;

import static com.example.quizbandeirafinal.R.id.imggrecia;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pergunta4 extends AppCompatActivity {
    private ImageView imgegito;
    private RadioGroup rgAlternativas4;
    private RadioButton rb1D, rb2D, rb3D, rb4D;
    private Button btnResponderD;

    private int pontuacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pergunta4);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imgegito = findViewById(R.id.imgegito);
        rgAlternativas4 = findViewById(R.id.rgAlternativas4);
        rb1D = findViewById(R.id.rb1D);
        rb2D = findViewById(R.id.rb2D);
        rb3D = findViewById(R.id.rb3D);
        rb4D = findViewById(R.id.rb4D);
        btnResponderD = findViewById(R.id.btnResponderD);

        pontuacao = getIntent().getIntExtra("pontuacao", 0);

        btnResponderD.setOnClickListener(view -> {
            int idSelecionado = rgAlternativas4.getCheckedRadioButtonId();

            if (idSelecionado == R.id.rb2D) {
                pontuacao++;
            }

            Intent i = new Intent(this, Pergunta5.class);
            i.putExtra("pontuacao", pontuacao);
            startActivity(i);
            finish();
        });
    }
}