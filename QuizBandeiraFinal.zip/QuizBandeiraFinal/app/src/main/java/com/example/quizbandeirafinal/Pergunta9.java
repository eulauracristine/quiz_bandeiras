package com.example.quizbandeirafinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pergunta9 extends AppCompatActivity {

    private ImageView imgveneto;
    private RadioGroup rgAlternativas9;
    private RadioButton rb1I, rb2I, rb3I, rb4I;
    private Button btnResponderI;

    private int pontuacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pergunta9);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imgveneto = findViewById(R.id.imgveneto);
        rgAlternativas9 = findViewById(R.id.rgAlternativas9);
        rb1I = findViewById(R.id.rb1I);
        rb2I = findViewById(R.id.rb2I);
        rb3I = findViewById(R.id.rb3I);
        rb4I = findViewById(R.id.rb4I);
        btnResponderI = findViewById(R.id.btnResponderI);

        pontuacao = getIntent().getIntExtra("pontuacao", 0);

        btnResponderI.setOnClickListener(view -> {
            int idSelecionado = rgAlternativas9.getCheckedRadioButtonId();

            if (idSelecionado == R.id.rb3I) {
                pontuacao++;
            }

            Intent i = new Intent(this, Pergunta10.class);
            i.putExtra("pontuacao", pontuacao);
            startActivity(i);
            finish();

        });
    }
}