package com.example.quizbandeirafinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pergunta2 extends AppCompatActivity {
    private ImageView ivBrasil;
    private RadioGroup rgAlternativas2;
    private RadioButton rb1B, rb2B, rb3B, rb4B;
    private Button btnResponderB;

    private int pontuacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pergunta2); // ✅ corrigido

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ivBrasil = findViewById(R.id.imggrecia);
        rgAlternativas2 = findViewById(R.id.rgAlternativas2);
        rb1B = findViewById(R.id.rb1B);
        rb2B = findViewById(R.id.rb2B);
        rb3B = findViewById(R.id.rb3B);
        rb4B = findViewById(R.id.rb4B);
        btnResponderB = findViewById(R.id.btnResponderB);

        pontuacao = getIntent().getIntExtra("pontuacao", 0);

        btnResponderB.setOnClickListener(view -> {
            int idSelecionado = rgAlternativas2.getCheckedRadioButtonId();

            if (idSelecionado == R.id.rb3B) {
                pontuacao++;
            }

            Intent i = new Intent(this, Pergunta3.class);
            i.putExtra("pontuacao", pontuacao);
            startActivity(i);
            finish();
        });
    }
}