package com.example.quizbandeirafinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Ranking extends AppCompatActivity {

    private TextView txtContador, txtNome;
    private Button btnResponderNovamente, btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // liga as variáveis aos componentes do XML
        txtNome = findViewById(R.id.txtNome);
        txtContador = findViewById(R.id.txtContador);
        btnResponderNovamente = findViewById(R.id.btnResponderNovamente);
        btnVoltar = findViewById(R.id.btnVoltar);

        txtNome.setText(Quiz.nome);

        // pega a pontuação que veio da tela anterior
        int pontuacao = getIntent().getIntExtra("pontuacao", 0);
        txtContador.setText(String.valueOf(pontuacao));

        btnResponderNovamente.setOnClickListener(v -> {
            Intent i = new Intent(this, Pergunta.class);
            i.putExtra("perguntaAtual", 0);
            i.putExtra("pontuacao", 0);
            startActivity(i);
            finish();
        });

        btnVoltar.setOnClickListener(v -> {
            startActivity(new Intent(this, TelaPrincipal.class));
            finish();
        });
    }
}