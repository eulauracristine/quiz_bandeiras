package com.example.quizbandeirafinal;

public class Quiz {
    public static String nome;
}