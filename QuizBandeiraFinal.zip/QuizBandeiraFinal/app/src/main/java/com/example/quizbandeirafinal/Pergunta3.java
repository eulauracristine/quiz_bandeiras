package com.example.quizbandeirafinal;

import static com.example.quizbandeirafinal.R.id.imggrecia;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pergunta3 extends AppCompatActivity {
    private ImageView imggrecia;
    private RadioGroup rgAlternativas3;
    private RadioButton rb1C, rb2C, rb3C, rb4C;
    private Button btnResponderC;

    private int pontuacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pergunta3);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imggrecia = findViewById(R.id.imggrecia);
        rgAlternativas3 = findViewById(R.id.rgAlternativas3);
        rb1C = findViewById(R.id.rb1C);
        rb2C = findViewById(R.id.rb2C);
        rb3C = findViewById(R.id.rb3C);
        rb4C = findViewById(R.id.rb4C);
        btnResponderC = findViewById(R.id.btnResponderC);

        pontuacao = getIntent().getIntExtra("pontuacao", 0);

        btnResponderC.setOnClickListener(view -> {
            int idSelecionado = rgAlternativas3.getCheckedRadioButtonId();

            if (idSelecionado == R.id.rb1C) {
                pontuacao++;
            }

            Intent i = new Intent(this, Pergunta4.class);
            i.putExtra("pontuacao", pontuacao);
            startActivity(i);
            finish();
        });
    }
}