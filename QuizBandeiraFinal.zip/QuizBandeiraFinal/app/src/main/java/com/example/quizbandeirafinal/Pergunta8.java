package com.example.quizbandeirafinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pergunta8 extends AppCompatActivity {

    private ImageView imgnepal;
    private RadioGroup rgAlternativas8;
    private RadioButton rb1H, rb2H, rb3H, rb4H;
    private Button btnResponderH;

    private int pontuacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pergunta8);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imgnepal = findViewById(R.id.imgnepal);
        rgAlternativas8 = findViewById(R.id.rgAlternativas8);
        rb1H = findViewById(R.id.rb1H);
        rb2H = findViewById(R.id.rb2H);
        rb3H = findViewById(R.id.rb3H);
        rb4H = findViewById(R.id.rb4H);
        btnResponderH = findViewById(R.id.btnResponderH);

        pontuacao = getIntent().getIntExtra("pontuacao", 0);

        btnResponderH.setOnClickListener(view -> {
            int idSelecionado = rgAlternativas8.getCheckedRadioButtonId();

            if (idSelecionado == R.id.rb3H) {
                pontuacao++;
            }

            Intent i = new Intent(this, Pergunta9.class);
            i.putExtra("pontuacao", pontuacao);
            startActivity(i);
            finish();

        });
    }
}