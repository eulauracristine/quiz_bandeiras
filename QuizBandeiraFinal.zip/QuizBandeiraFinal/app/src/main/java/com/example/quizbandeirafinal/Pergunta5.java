package com.example.quizbandeirafinal;

import static com.example.quizbandeirafinal.R.id.imggrecia;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pergunta5 extends AppCompatActivity {
    private ImageView imgbolivia;
    private RadioGroup rgAlternativas5;
    private RadioButton rb1E, rb2E, rb3E, rb4E;
    private Button btnResponderE;

    private int pontuacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pergunta5);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imgbolivia = findViewById(R.id.imgbolivia);
        rgAlternativas5 = findViewById(R.id.rgAlternativas5);
        rb1E = findViewById(R.id.rb1E);
        rb2E = findViewById(R.id.rb2E);
        rb3E = findViewById(R.id.rb3E);
        rb4E = findViewById(R.id.rb4E);
        btnResponderE = findViewById(R.id.btnResponderE);

        pontuacao = getIntent().getIntExtra("pontuacao", 0);

        btnResponderE.setOnClickListener(view -> {
            int idSelecionado = rgAlternativas5.getCheckedRadioButtonId();

            if (idSelecionado == R.id.rb1E) {
                pontuacao++;
            }

            Intent i = new Intent(this, Pergunta6.class);
            i.putExtra("pontuacao", pontuacao);
            startActivity(i);
            finish();
        });
    }
}