package br.edu.unicid.quizbandeiras;

public class Pontuacao {

    public static int pontos = 0;

}

