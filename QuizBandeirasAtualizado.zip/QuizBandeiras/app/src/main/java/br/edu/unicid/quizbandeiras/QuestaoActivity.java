package br.edu.unicid.quizbandeiras;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class QuestaoActivity extends AppCompatActivity {

    private RadioGroup radioGroupRespostas;
    private Button btnResponder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_questao);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {

                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                    );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        radioGroupRespostas = findViewById(R.id.radioGroupRespostas);
        btnResponder = findViewById(R.id.btnResponder);

        btnResponder.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                int idSelecionado =
                        radioGroupRespostas.getCheckedRadioButtonId();

                if (idSelecionado == -1) {
                    return;
                }

                if (idSelecionado == R.id.rdbA) {
                    br.edu.unicid.quizbandeiras.Pontuacao.pontos++;
                }

                Intent intent = new Intent(
                        QuestaoActivity.this,
                        MainActivity.class
                );

                startActivity(intent);
            }
        });
    }
}
