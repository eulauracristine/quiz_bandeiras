package br.edu.unicid.quizbandeiras;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PerguntaActivity extends AppCompatActivity {

    private RadioGroup radioGroupRespostas;
    private Button btnConfirmar;
    private int pontosAtuais = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta);

        // 1. Pega os pontos que vieram da tela anterior
        pontosAtuais = getIntent().getIntExtra("TOTAL_PONTOS", 0);

        radioGroupRespostas = findViewById(R.id.radioGroupRespostas);
        btnConfirmar = findViewById(R.id.btnConfirmar);

        btnConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Descobre qual RadioButton foi marcado pelo usuário
                int idSelecionado = radioGroupRespostas.getCheckedRadioButtonId();

                // Valida se o usuário esqueceu de marcar alguma opção
                if (idSelecionado == -1) {
                    Toast.makeText(PerguntaActivity.this, "Selecione uma resposta!", Toast.LENGTH_SHORT).show();
                    return; // Para a execução aqui para não quebrar o app
                }

                // 2. Confere se a opção marcada é a correta
                // Digamos que a alternativa correta seja a Opção B (R.id.rbOpcaoB)
                if (idSelecionado == R.id.rbOpcaoB) {
                    // ACERTOU! Soma +1 ponto
                    pontosAtuais++;
                    Toast.makeText(PerguntaActivity.this, "Resposta Correta!", Toast.LENGTH_SHORT).show();
                } else {
                    // ERROU!
                    Toast.makeText(PerguntaActivity.this, "Resposta Errada!", Toast.LENGTH_SHORT).show();
                }

                // 3. Vai para a próxima tela (ou tela final) levando os pontos atualizados
                Intent intent = new Intent(PerguntaActivity.this, ProximaTela.class);
                intent.putExtra("TOTAL_PONTOS", pontosAtuais);
                startActivity(intent);
                finish();
            }
        });
    }
}