package br.edu.unicid.projeto_quiz;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    //declarações private
    private Button btnIniciar, btnSair;
    private EditText edtNome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //configurando findview by id
        btnSair = findViewById(R.id.btnSair);
        btnIniciar = findViewById(R.id.btnIniciar);
        edtNome = findViewById(R.id.edtNome);

        //pra iniciar
        btnIniciar.setOnClickListener(v -> iniciar(v));
    }

    //para liberar o botão


    //métodos

    //sair
    public void sair (View view){
        finish();
    }

    //iniciar
    public void iniciar (View view){
        String nome = edtNome.getText().toString().trim();

        if (nome.isEmpty()) {
            edtNome.setError("Digite seu nome");
            return;
        }
        Intent intent = new Intent(MainActivity.this, tela2.class);
        intent.putExtra("nome", nome);
        startActivity(intent);
    }

}